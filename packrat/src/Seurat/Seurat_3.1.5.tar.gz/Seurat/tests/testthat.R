library(testthat)
library(Seurat)

test_check("Seurat")
