library(testthat)
library(uwot)

test_check("uwot")
